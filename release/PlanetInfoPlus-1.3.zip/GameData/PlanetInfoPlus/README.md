# PlanetInfoPlus
Enhanced information in the "planet info" panel in the tracking station and in the map view in flight.

Includes in-game settings for controlling which information is shown.

Customizable numeric formats via config file.

